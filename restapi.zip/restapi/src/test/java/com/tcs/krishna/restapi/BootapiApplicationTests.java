package com.tcs.krishna.restapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
