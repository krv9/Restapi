package com.tcs.krishna.restapi.controller;


import com.tcs.krishna.restapi.dto.EmployeeDTO;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;

@RestController
public class EmployeeController {
//    @GetMapping(path = "/employees")
//    public String getEmployees(){
//        return "Hello World";
//    }
    @GetMapping(path = "/employees")
    public EmployeeDTO getEmployees(){
        return new EmployeeDTO(12l,"krishna", LocalDate.of(2024,12,2),true);
    }
}
