package com.tcs.krishna.restapi;

public interface DB {
    public String getdata();
}
