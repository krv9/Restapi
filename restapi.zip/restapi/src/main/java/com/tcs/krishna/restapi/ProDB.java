package com.tcs.krishna.restapi;

public class ProDB implements DB{

    public String getdata() {
        return "Production Database";
    }
}
