package com.tcs.krishna.restapi;

public class DevDB implements DB
{
    public  String getdata(){
        return "Development Database";
}
}
